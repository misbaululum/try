<div class="navbar-nav ml-auto">
    <a class="nav-item nav-link" href="logout">Logout</a>
</div>
