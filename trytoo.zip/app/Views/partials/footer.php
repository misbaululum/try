<footer class="footer mt-5">
    <div class="container">
        <a class="footer" href="<?= base_url() ?>"></a>
        <div class="row">
            <div class="col">
                <!-- Konten footer di sini -->
                <p>&copy; <?= date('Y'); ?> Primadaya Plastisindo</p>
            </div>
        </div>
    </div>
</footer>
